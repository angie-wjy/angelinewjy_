import { Injectable } from '@angular/core';
import Dexie from 'dexie';

export interface CerbungItem {
  id: number;
  title: string;
  penulis: string;
  desc: string;
  image: string;
  genre: string;
  tanggal: string;
  paragraf: string;
}

@Injectable({
  providedIn: 'root'
})
export class DexieService extends Dexie {

  cerbungStore: Dexie.Table<CerbungItem, number>;

  constructor() {
    super('CerbungDatabase')
    this.version(1).stores({ cerbungStore: '++id, title, penulis, desc, image, genre, tanggal, paragraft' });
    this.cerbungStore = this.table('cerbungStore');
  }

  async addCerbung(title: string, penulis: string, desc: string, image: string, genre: string, tanggal: string, paragraf: string): Promise<void> {
    await this.cerbungStore.add({
      title, penulis, desc, image, genre, tanggal, paragraf,
      id: 0
    });
  }

  async updateCerbung(id: number, title: string, penulis: string, desc: string, image: string, genre: string, tanggal: string, paragraft: string): Promise<void> {
    await this.cerbungStore.update(id, { title, penulis, desc, image, genre, tanggal, paragraft });
  }

  async deleteCerbung(id: number): Promise<void> {
    await this.cerbungStore.delete(id);
  }

  async getCerbungList(): Promise<CerbungItem[]> {
    return this.cerbungStore.toArray();
  }

  async getCerbungDetail(id: number): Promise<CerbungItem | undefined> {
    return this.cerbungStore.get(id);
  }
}
