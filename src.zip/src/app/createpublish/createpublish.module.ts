import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreatepublishPageRoutingModule } from './createpublish-routing.module';

import { CreatepublishPage } from './createpublish.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreatepublishPageRoutingModule
  ],
  declarations: [CreatepublishPage]
})
export class CreatepublishPageModule {}
