import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-createpublish',
  templateUrl: './createpublish.page.html',
  styleUrls: ['./createpublish.page.scss'],
})
export class CreatepublishPage implements OnInit {

  index = 0

  cerbungs:any[] = []
  constructor(private route:ActivatedRoute, private foodservice: FoodserviceService) { }

  ngOnInit() {
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
}
