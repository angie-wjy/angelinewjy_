import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreatepublishPage } from './createpublish.page';

const routes: Routes = [
  {
    path: '',
    component: CreatepublishPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreatepublishPageRoutingModule {}
