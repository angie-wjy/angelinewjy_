import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreatepublishPage } from './createpublish.page';

describe('CreatepublishPage', () => {
  let component: CreatepublishPage;
  let fixture: ComponentFixture<CreatepublishPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CreatepublishPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
