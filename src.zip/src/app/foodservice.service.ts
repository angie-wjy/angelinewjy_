import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FoodserviceService {
  
  // cerbung: any[] = [];
  // cerbungs = [
  //   {
  //     name: "cerita sasa",
  //     penulis: "sasa",
  //     url: "https://picsum.photos/200/300",
  //     description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's " +
  //       "standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book." +
  //       "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  //     genre: "Aksi",
  //     tanggal: "17/09/2023",
  //     visi: "",
  //     para: "Halo"
  //   },
  //   {
  //     name: "cerita angie",
  //     penulis: "angie",
  //     url: "https://picsum.photos/200",
  //     description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's " +
  //       "standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book." +
  //       "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  //     genre: "Kocak",
  //     tanggal: "15/08/2022",
  //     visi: "",
  //     para: "Hai"
  //   },
  //   {
  //     name: "cerita ima",
  //     penulis: "ima",
  //     url: "https://picsum.photos/100",
  //     description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's " +
  //       "standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book." +
  //       "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  //     genre: "Horor",
  //     tanggal: "10/05/2020",
  //     visi: "",
  //     para: "baik"

  //   }, {
  //     name: "cerita tata",
  //     penulis: "tata",
  //     url: "https://picsum.photos/300",
  //     description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's " +
  //       "standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book." +
  //       "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  //     genre: "Aksi",
  //     tanggal: "15/10/2023",
  //     visi: "",
  //     para: "Oke"

  //   }, {
  //     name: "cerita melly",
  //     penulis: "melly",
  //     url: "https://picsum.photos/400",
  //     description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's " +
  //       "standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book." +
  //       "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
  //     genre: "Kocak",
  //     tanggal: "17/09/2021",
  //     visi: "",
  //     para: "Pagi"

  //   },
  //];

  constructor(private http: HttpClient) { }

  addAccount(c_username: string, c_name: string, c_password: string, c_retypepassword: string, c_picture: string, c_image: string ) {

    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    const body = new URLSearchParams();
    body.set('username', c_username);
    body.set('name', c_name);
    body.set('password', c_password);
    body.set('retype_password', c_retypepassword);
    body.set('profile_picture', c_picture);
    body.set('image', c_image);
    const urlEncodedData = body.toString();
    return this.http.post(
      "https://ubaya.me/hybrid/160721011/signup.php", urlEncodedData, { headers });

  }

  addCerbung(c_title: string, c_desc: string, 
             c_genre: string, c_access: string,
             c_paragraft: string, c_id: number) {

    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    const body = new URLSearchParams();
    body.set('title', c_title);
    body.set('desc', c_desc);
    body.set('genre', c_genre);
    body.set('paragraft', c_paragraft);
    body.set('id', c_id.toString());
    const urlEncodedData = body.toString();
    return this.http.post(
      "https://ubaya.me/hybrid/160721011/addcerbung.php", urlEncodedData, { headers });

  }

  

  updateCerbung(c_title: string, c_penulis: string, c_desc: string, c_image: string, c_genre: string, c_tanggal: string, c_paragraft: string, c_id: number) {
    // this.pastas.push({
    //   name : p_name, url: p_image, description: p_desc, price: p_price, spicy:p_spicy
    // })

    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    const body = new URLSearchParams();
    body.set('title', c_title);
    body.set('penulis', c_penulis);
    body.set('desc', c_desc);
    body.set('image', c_image);
    body.set('tanggal', c_tanggal);
    body.set('paragraft', c_paragraft);
    body.set('id', c_id.toString());
    const urlEncodedData = body.toString();
    return this.http.post(
      "https://ubaya.me/hybrid/160721011/update_cerbung.php", urlEncodedData, { headers });

  }

  deleteCerbung(c_id:number)
{
  const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
  const body = new URLSearchParams();
  body.set('id', c_id.toString()); const urlEncodedData = body.toString();
  return this.http.post("https://ubaya.me/hybrid/160721011/delete_pasta.php", urlEncodedData, { headers });
}

login(c_username: string, c_password: string)
{
  const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
  const body = new URLSearchParams();
  body.set('username', c_username.toString()); 
  body.set('password', c_password.toString()); 
  const urlEncodedData = body.toString();
  return this.http.post("https://ubaya.me/hybrid/160721011/login.php", urlEncodedData, { headers });
}

submitCerbung(new_title: string, new_penulis: string, new_desc: string, new_image: string, new_genre: string, new_tanggal: string, new_paragraft: string, new_id: number): Observable<any> {
  const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
  const body = new URLSearchParams();
  body.set('title', new_title);
    body.set('penulis', new_penulis);
    body.set('desc', new_desc);
    body.set('image', new_image);
    body.set('tanggal', new_tanggal);
    body.set('paragraft', new_paragraft);
    body.set('id', new_id.toString());
    //body.set('id', new_id.toString());
  const urlEncodedData = body.toString();
  return this.http.post("https://ubaya.me/hybrid/160721011/addcerbung.php", urlEncodedData, { headers });
}

uploadImage(c_name:string, c_base64:string)
{
  const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
  const body = new URLSearchParams();
  body.set('name', c_name.toString()); 
  body.set('base64',c_base64.toString()); 
  const urlEncodedData = body.toString();
  return this.http.post("https://ubaya.me/hybrid/160721011/picture_URL.php", urlEncodedData, { headers });
}


  cerbungList(): Observable<any> {
    return this.http.get("https://ubaya.me/hybrid/160721011/cerbungs.php");
  }

  cerbungDetail(id: number): Observable<any> {
    return this.http.get("https://ubaya.me/hybrid/160721011/cerbung_detail.php?id=" + id);
  }

  generateNumberOptions(start: number, end: number, step: number): number[] {
    const options: number[] = [];
    for (let i = start; i <= end; i += step) {
      options.push(i);
    }
    return options;
}
}