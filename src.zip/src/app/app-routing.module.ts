import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'signin',
    pathMatch: 'full'
  },
  {
    path: 'create',
    loadChildren: () => import('./create/create.module').then( m => m.CreatePageModule)
  },
  {
    path: 'users',
    loadChildren: () => import('./users/users.module').then( m => m.UsersPageModule)
  },
  {
    path: 'usersdetails',
    loadChildren: () => import('./usersdetails/usersdetails.module').then( m => m.UsersdetailsPageModule)
  },
  {
    path: 'prefs',
    loadChildren: () => import('./prefs/prefs.module').then( m => m.PrefsPageModule)
  },
  {
    path: 'following',
    loadChildren: () => import('./following/following.module').then( m => m.FollowingPageModule)
  },
  {
    path: 'createaccess',
    loadChildren: () => import('./createaccess/createaccess.module').then( m => m.CreateaccessPageModule)
  },
  {
    path: 'createpublish',
    loadChildren: () => import('./createpublish/createpublish.module').then( m => m.CreatepublishPageModule)
  },
  {
    path: 'signin',
    loadChildren: () => import('./signin/signin.module').then( m => m.SigninPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'followlike',
    loadChildren: () => import('./followlike/followlike.module').then( m => m.FollowlikePageModule)
  },
  {
    path: 'notification',
    loadChildren: () => import('./notification/notification.module').then( m => m.NotificationPageModule)
  },
  {
    path: 'respond',
    loadChildren: () => import('./respond/respond.module').then( m => m.RespondPageModule)
  },
  {
    path: 'read/:index',
    loadChildren: () => import('./read/read.module').then( m => m.ReadPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
