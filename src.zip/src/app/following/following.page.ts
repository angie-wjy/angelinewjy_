import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-following',
  templateUrl: './following.page.html',
  styleUrls: ['./following.page.scss'],
})
export class FollowingPage {

  textareaValue: string = '';

  index = 0
  jenistampilan = "card"
  cerbungs:any[] = []

  chunkArray(arr: any[], chunkSize: number): any[][] {
    const result = [];
    for (let i = 0; i < arr.length; i += chunkSize) {
      result.push(arr.slice(i, i + chunkSize));
    }
    return result;
  }

  constructor(private router: Router, private route: ActivatedRoute, private foodservice: FoodserviceService) { }

  ngOnInit() {
    //this.cerbungs = this.foodservice.cerbungs
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
}
