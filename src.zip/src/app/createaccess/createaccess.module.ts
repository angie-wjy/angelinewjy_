import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreateaccessPageRoutingModule } from './createaccess-routing.module';

import { CreateaccessPage } from './createaccess.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreateaccessPageRoutingModule
  ],
  declarations: [CreateaccessPage]
})
export class CreateaccessPageModule {}
