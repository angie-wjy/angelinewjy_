import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateaccessPage } from './createaccess.page';

describe('CreateaccessPage', () => {
  let component: CreateaccessPage;
  let fixture: ComponentFixture<CreateaccessPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CreateaccessPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
