import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-createaccess',
  templateUrl: './createaccess.page.html',
  styleUrls: ['./createaccess.page.scss'],
})
export class CreateaccessPage implements OnInit {

  index = 0
  new_paragraft = ""

  cerbungs:any[] = []
  constructor(private route:ActivatedRoute, private foodservice: FoodserviceService) { }

  ngOnInit() {
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
  //   LimitCounter(event: any) {
  //     // Menghitung jumlah kata dalam teks
  //     const inputText = event.target.value;
  //     const words = inputText.split(/\s+/);
  //     this.jumlahKata = words.length - 1; // Mengurangi satu karena split menghasilkan satu elemen kosong
  //     this.kata = words.length - 1; // Mengurangi satu karena split menghasilkan satu elemen kosong
  
  
  //     // Batasan maksimal 70 kata
  //     if (this.jumlahKata > 70) {
  //       // Jika lebih dari 70 kata, hapus kata yang kelebihan
  //       const trimmedText = words.slice(0, 70).join(' ');
  //       this.paragrafs = trimmedText;
  //       this.kata = 70
  //       this.showWordCountAlert();
  //     }
  //   }
  }


