import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-read',
  templateUrl: './read.page.html',
  styleUrls: ['./read.page.scss'],
})
export class ReadPage implements OnInit {

  cerbungs: any[] = []
  index = 0

  constructor(private router: Router, private route: ActivatedRoute, private foodservice: FoodserviceService) { }

  ngOnInit() {
    this.route.params.subscribe(
      params => {
        this.index = params['index']
      }
    )
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
}