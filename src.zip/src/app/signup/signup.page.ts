import { Component, OnInit } from '@angular/core';
import { FoodserviceService } from '../foodservice.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {

  new_user = ""
  new_name = ""
  new_pass = ""
  new_repass = ""
  new_profile = ""
  new_url = ""

  constructor(private foodservice: FoodserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe
  }

  addAccount(){
    this.new_url = "https://ubaya.me/hybrid/160721011/signup.php"
    this.foodservice.addAccount(
      this.new_user, this.new_name, this.new_pass, 
      this.new_repass, this.new_profile, this.new_url
      ).subscribe(
        (response: any) => {
          if (response.result == 'success') {
            alert('Sukses!')
          } else {
            alert(response.message)
          }
        }
      )
    }

}
