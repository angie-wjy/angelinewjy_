import { Component } from '@angular/core';
import { FoodserviceService } from './foodservice.service';
import {defineCustomElements} from '@ionic/pwa-elements/loader'

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  username=""
  name=""
  password=""

  constructor(private foodservice:FoodserviceService) {
    defineCustomElements(window)
    this.name = localStorage.getItem("app_name")??'' //one line if
    this.username = localStorage.getItem("app_username")??''
  }

  login(){
    this.foodservice.login(this.username, this.password).subscribe(
      (response:any) => {
        if(response.result === 'success'){
          alert("Sukses")
          this.name = response.name
          localStorage.setItem("app_name", this.name)
          localStorage.setItem("app_username", this.username)
        }else{
          alert(response.message)
        }
      }
    )
  }

  logout(){
    this.username = ""
    this.name = ""
    localStorage.removeItem("app_username")
    localStorage.removeItem("app_name")
  }
}
