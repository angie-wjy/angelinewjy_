import { Component, OnInit } from '@angular/core';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.page.html',
  styleUrls: ['./users.page.scss'],
})
export class UsersPage implements OnInit {

  jenistampilan = 'accordion'

  cerbungs:any[]=[]

  constructor(private foodservice:FoodserviceService) { }

  ngOnInit() {
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
}
