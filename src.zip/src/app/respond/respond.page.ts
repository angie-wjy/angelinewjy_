import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-respond',
  templateUrl: './respond.page.html',
  styleUrls: ['./respond.page.scss'],
})
export class RespondPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
