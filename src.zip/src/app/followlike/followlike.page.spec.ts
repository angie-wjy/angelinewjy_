import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FollowlikePage } from './followlike.page';

describe('FollowlikePage', () => {
  let component: FollowlikePage;
  let fixture: ComponentFixture<FollowlikePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(FollowlikePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
