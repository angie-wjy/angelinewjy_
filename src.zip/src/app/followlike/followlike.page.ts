import { Component, OnInit } from '@angular/core';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-followlike',
  templateUrl: './followlike.page.html',
  styleUrls: ['./followlike.page.scss'],
})
export class FollowlikePage implements OnInit {

  jenistampilan = 'accordion'

  cerbungs:any[]=[]
  constructor(private foodservice:FoodserviceService) { }

  ngOnInit() {
    //this.cerbungs = this.foodservice.cerbungList
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }
}

