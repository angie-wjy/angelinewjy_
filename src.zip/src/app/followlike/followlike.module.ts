import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FollowlikePageRoutingModule } from './followlike-routing.module';

import { FollowlikePage } from './followlike.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FollowlikePageRoutingModule
  ],
  declarations: [FollowlikePage]
})
export class FollowlikePageModule {}
