import { Component } from '@angular/core';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  jenistampilan = "card"
  txtCerbung = ""

  cerbungs:any[] = []

  // chunkArray(arr: any[], chunkSize: number): any[][] {
  //   const result = [];
  //   for (let i = 0; i < arr.length; i += chunkSize) {
  //     result.push(arr.slice(i, i + chunkSize));
  //   }
  //   return result;
  // }


  constructor(private foodservice: FoodserviceService) { }

  ngOnInit() {
    this.foodservice.cerbungList().subscribe(
      (data) => {
        this.cerbungs = data
      }
    )
  }

  refreshList() {
    const searchTerm = this.txtCerbung.toLowerCase();
    if (!searchTerm) {
      this.foodservice.cerbungList().subscribe((data) => {
        this.cerbungs = data;
      });
    } else {
      this.cerbungs = this.cerbungs.filter((cerbung) =>
        cerbung.name.toLowerCase().includes(searchTerm)
      );
    }
  }
}
