import { Component, OnInit } from '@angular/core';
import { FoodserviceService } from '../foodservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.page.html',
  styleUrls: ['./create.page.scss'],
})
export class CreatePage implements OnInit {

  new_title =""
  new_penulis = ""
  new_desc = ""
  new_genre = ""
  new_paragraft = ""
  new_tanggal = ""
  new_image = ""
  new_id = 0
  jenistampilan = "card"

  cerbungs:any[] = []

  chunkArray(arr: any[], chunkSize: number): any[][] {
    const result = [];
    for (let i = 0; i < arr.length; i += chunkSize) {
      result.push(arr.slice(i, i + chunkSize));
    }
    return result;
  }


  constructor(private foodservice: FoodserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    //this.cerbungs = this.foodservice.submitCerbung
    this.route.params.subscribe
  }

  submit() {
    this.foodservice.submitCerbung(
      this.new_title, this.new_penulis, this.new_desc, 
      this.new_genre, this.new_image, this.new_tanggal, 
      this.new_paragraft, this.new_id
      ).subscribe(
      (response: any) => {
        if (response.result == 'success') {
          alert('Sukses!')
        } else {
          alert(response.message)
        }
      }
    )
    this.new_title = ""
    this.new_penulis = ""
    this.new_desc = ""
    this.new_genre = ""
    this.new_paragraft = ""
    this.new_tanggal = ""
    this.new_image =""

    //this.route.navigate(['/following'])
  }
}


