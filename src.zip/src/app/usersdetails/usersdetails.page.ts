import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersdetails',
  templateUrl: './usersdetails.page.html',
  styleUrls: ['./usersdetails.page.scss'],
})
export class UsersdetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
