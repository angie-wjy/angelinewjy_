package com.ubaya.uas_cerbung

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewParent
import androidx.recyclerview.widget.RecyclerView
import com.ubaya.uas_cerbung.databinding.ActivityCerbungReadItemBinding
import java.text.FieldPosition

class ReadFragmentAdapter(val para:ArrayList<Paragraf>) : RecyclerView.Adapter<ReadFragmentAdapter.ReadViewHolder>(){

    class ReadViewHolder(val binding: ActivityCerbungReadItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReadViewHolder {
        val binding = ActivityCerbungReadItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ReadViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ReadViewHolder, position: Int) {
        with(holder.binding) {
            txtIsi.text = para[position].para
            txtNama.text = para[position].wriName
        }
    }

    override fun getItemCount(): Int {
        return para.size
    }
}