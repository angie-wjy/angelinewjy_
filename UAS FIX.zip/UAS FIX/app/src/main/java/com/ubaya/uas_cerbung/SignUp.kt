package com.ubaya.uas_cerbung

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.Response.Listener
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.ubaya.uas_cerbung.databinding.ActivitySignInBinding
import com.ubaya.uas_cerbung.databinding.ActivitySignUpBinding
import org.json.JSONException
import org.json.JSONObject
import java.util.Calendar

class SignUp : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var binding = ActivitySignUpBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.btnRegister.setOnClickListener(){
            val cal = Calendar.getInstance()
            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH)
            val day = cal.get(Calendar.DAY_OF_MONTH)

            val date = "$year-$month-$day"

            if (binding.txtFullname.text.toString() == ""
                && binding.txtURL.text.toString() == ""
                && binding.txtUserUp.text.toString() == ""
                && binding.txtPassUp.text.toString() == ""
                && binding.txtKonfirUp.text.toString() == "")
            {
                Toast.makeText(this, "All fields must be filled in.", Toast.LENGTH_SHORT).show()
            }
            else
            {
                if (binding.txtPassUp.text.toString() == binding.txtKonfirUp.text.toString()) {
                    var url = "https://ubaya.me/native/160721016/signup.php"
                    val stringRequest = object : StringRequest(
                        Request.Method.POST, url,
                        Response.Listener { response ->
                            try {
                                val jsonResponse = JSONObject(response)
                                val result = jsonResponse.getString("result")

                                if (result == "success") {
                                    Toast.makeText(this, "Your account has been successfully created", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this, SignIn::class.java)
                                    startActivity(intent)
                                }
                                else
                                {
                                    Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: JSONException) {
                                Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show()
                            }
                                          },
                        Response.ErrorListener { error -> Toast.makeText(this, "Error in volley respon error", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        override fun getParams(): MutableMap<String, String> {
                            val params = HashMap<String, String>()
                            params["user"] = binding.txtUserUp.text.toString()
                            params["pass"] = binding.txtPassUp.text.toString()
                            params["name"] = binding.txtFullname.text.toString()
                            params["url"] = binding.txtURL.text.toString()
                            return params
                        }
                    }
                    Volley.newRequestQueue(this).add(stringRequest)
                } else {
                    Toast.makeText(this, "The password and confirmation password must match", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}