package com.ubaya.uas_cerbung

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.SyncStateContract.Helpers.update
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import com.ubaya.uas_cerbung.databinding.FragmentReadBinding
import org.json.JSONException
import org.json.JSONObject

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [ReadFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ReadFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private lateinit var binding: FragmentReadBinding
    private lateinit var sharedPreferences: SharedPreferences
    var para: ArrayList<Paragraf> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        sharedPreferences = requireActivity().getSharedPreferences("MyPre", Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentReadBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val cerbung = arguments?.getParcelable<Cerbung>("cerbung")
        val id = cerbung?.id
        val idUser = sharedPreferences.getString("app_id", "Not Found").toString()

        if (cerbung != null){
            binding.txtTitleRead.text = cerbung?.title.toString()
            binding.btnGenreRead.text = cerbung?.genre.toString()
            binding.btnAccessRead.text = cerbung?.access.toString()
            binding.txtDateRead.text = cerbung?.date.toString()
            binding.txtUserRead.text = cerbung?.user.toString()
            binding.txtDescRead.text = cerbung?.desc.toString()

            likeRead(cerbung?.id){ res ->
                binding.txtLikeRead.text = res
            }

            paraRead(cerbung?.id){ res ->
                binding.txtRankRead.text = res
            }

            val url = cerbung?.url.toString()
            Picasso.get().load(url).into(binding.urlRead)
        }

        binding.btnSubmitRead.setOnClickListener(){
            val paraIn = binding.paraRead.text
            addPara(idUser.toInt(), id, paraIn.toString())
        }

        update()
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ReadFragment.
         */

        private const val ARG_CERBUNG = "cerbung"
        @JvmStatic
        fun newInstance(cerbung: Cerbung): ReadFragment {
            val fragment = ReadFragment()
            val args = Bundle()
            args.putParcelable("cerbung", cerbung)
            fragment.arguments = args
            return fragment
        }
    }

    fun addPara(idUser: Int, id: Int?, paraIn: String ){

    }

    fun update(){
        val lm = LinearLayoutManager(activity)
        with(binding.RecyclerViewHome){
            layoutManager = lm
            setHasFixedSize(true)
            adapter = ReadFragmentAdapter(para)
        }
    }

    fun likeRead(id: Int?, callback: (String) -> Unit){
        val url = "https://ubaya.me/native/160721016/likeRead.php"

        val stringRequest = object : StringRequest (
            Method.POST, url,
            Response.Listener { response ->
                Log.d("apiresLike", response.toString())
                try {
                    val jsonResponse = JSONObject(response)
                    val resValue = jsonResponse.getString("res")
                    val total = jsonResponse.getString("like")

                    if(resValue == "success"){
                        callback(total.toString())
                    } else {
                        callback("ERROR")
                    }
                } catch (e: JSONException){
                    callback("ERROR")
                }
            },
            Response.ErrorListener { error ->
                Log.d("apiresLike", error.toString())
                callback("ERROR")
            }
        ){
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["id"] = id.toString()
                return params
            }
        }
        Volley.newRequestQueue(context).add(stringRequest)
    }

    fun paraRead(id: Int?, callback: (String) -> Unit){
        val url = "https://ubaya.me/native/160721016/paraRead.php"

        val stringRequest = object : StringRequest (
            Method.POST, url,
            Response.Listener { response ->
                Log.d("apiresPara", response.toString())
                try {
                    val jsonResponse = JSONObject(response)
                    val resValue = jsonResponse.getString("res")
                    val total = jsonResponse.getString("para")

                    if(resValue == "success"){
                        callback(total.toString())
                    } else {
                        callback("ERROR")
                    }
                } catch (e: JSONException){
                    callback("ERROR")
                }
            },
            Response.ErrorListener { error ->
                Log.d("apiresPara", error.toString())
                callback("ERROR")
            }
        ){
            override fun getParams(): MutableMap<String, String>? {
                val params = HashMap<String, String>()
                params["id"] = id.toString()
                return params
            }
        }
        Volley.newRequestQueue(context).add(stringRequest)
        }
    }