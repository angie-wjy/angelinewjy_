package com.ubaya.uas_cerbung

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.squareup.picasso.Picasso
import com.ubaya.uas_cerbung.databinding.ActivityCerbungItemBinding
import com.ubaya.uas_cerbung.databinding.ActivityReadBinding

class Read : AppCompatActivity() {
    private lateinit var binding: ActivityCerbungItemBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCerbungItemBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val cerbung : Cerbung = intent.getSerializableExtra("cerbung") as Cerbung

        Picasso.get().load(cerbung.url).into(binding.imgPoster)
        binding.txtTitleCard.text = cerbung.title
        binding.txtDesc.text = cerbung.desc
        binding.txtWriter.text = cerbung.user
    }
}