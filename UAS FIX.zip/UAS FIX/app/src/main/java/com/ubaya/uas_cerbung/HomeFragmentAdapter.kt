package com.ubaya.uas_cerbung

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import com.ubaya.uas_cerbung.databinding.ActivityCerbungItemBinding
import org.json.JSONException
import org.json.JSONObject

class HomeFragmentAdapter(
    val cerbungs: ArrayList<Cerbung>,
    val context: Context,
    private val read: OnReadClickListener)
    : RecyclerView.Adapter<HomeFragmentAdapter.HomeViewHolder>(){

    class HomeViewHolder(val binding: ActivityCerbungItemBinding): RecyclerView.ViewHolder(binding.root)

    interface OnReadClickListener {
        fun OnReadClickListener(cerbung: Cerbung)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        val binding = ActivityCerbungItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HomeFragmentAdapter.HomeViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return cerbungs.size
    }

    fun cerbungLike(id: Int, callback: (String) -> Unit) {
        val url = "https://ubaya.me/native/160721015/cerbungLike.php"

        val stringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                Log.d("resLlike", response.toString())
                try {
                    val jsonResponse = JSONObject(response)
                    val resValue = jsonResponse.getString("result")
                    val total = jsonResponse.getString("like")

                    if (resValue == "success") {
                        callback(total.toString())
                    } else {
                        callback("Error")
                    }
                } catch (e: JSONException) {
                    callback("Error")
                }
            },
            Response.ErrorListener { error ->
                Log.d("resLike", error.toString())
                // Handle error
                callback("Error")
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["id"] = id.toString()
                return params
            }
        }

        Volley.newRequestQueue(context).add(stringRequest)
    }

    fun cerbungPara(id: Int, callback: (String) -> Unit) {
        val url = "https://ubaya.me/native/160721015/cerbungPara.php"

        val stringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                Log.d("resPara", response.toString())
                try {
                    val jsonResponse = JSONObject(response)
                    val resultValue = jsonResponse.getString("result")
                    val total = jsonResponse.getString("paragraf")

                    if (resultValue == "success") {
                        callback(total.toString())
                    } else {
                        callback("Error")
                    }
                } catch (e: JSONException) {
                    // Handle JSON parsing error
                    callback("Error")
                }
            },
            Response.ErrorListener { error ->
                Log.d("resPara", error.toString())
                // Handle error
                callback("Error")
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["id"] = id.toString()
                return params
            }
        }

        Volley.newRequestQueue(context).add(stringRequest)
    }

    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        val url = cerbungs[position].url
        val builder = Picasso.Builder(holder.itemView.context)

        builder.listener { picasso, uri, exception -> exception.printStackTrace() }
        Picasso.get().load(url).into(holder.binding.imgPoster)

        with(holder.binding) {
            txtTitleCard.text = cerbungs[position].title
            txtWriter.text = cerbungs[position].user
            txtDesc.text = cerbungs[position].desc

            cerbungLike(cerbungs[position].id){ result ->
                txtLike.text = result
            }

            cerbungPara(cerbungs[position].id){ result ->
                txtRank.text = result
            }

            btnRead.setOnClickListener {
                read.OnReadClickListener(cerbungs[position])
            }
        }
    }
}