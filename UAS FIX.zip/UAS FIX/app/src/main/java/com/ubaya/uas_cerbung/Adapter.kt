package com.ubaya.uas_cerbung

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.ubaya.uas_cerbung.Cerbung
import com.ubaya.uas_cerbung.Read
import com.ubaya.uas_cerbung.databinding.ActivityCerbungItemBinding

class Adapter(val cerbungs:ArrayList<Cerbung>) : RecyclerView.Adapter<Adapter.AdapterViewHolder>() {
    class AdapterViewHolder(val binding: ActivityCerbungItemBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapterViewHolder {
        val binding = ActivityCerbungItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return AdapterViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return cerbungs.size
    }

    override fun onBindViewHolder(holder: AdapterViewHolder, position: Int) {
        val url = cerbungs[position].url
        with(holder.binding) {
            val builder = Picasso.Builder(holder.itemView.context)
            builder.listener { picasso, uri, exception -> exception.printStackTrace() }
            Picasso.get().load(url).into(holder.binding.imgPoster)
            holder.binding.txtTitleCard.text = cerbungs[position].title
            holder.binding.txtWriter.text = cerbungs[position].user
            holder.binding.txtDesc.text = cerbungs[position].paragraph

            btnRead.setOnClickListener(){
                val intent = Intent(it.context, Read::class.java)
                intent.putExtra("cerbung", position)
                it.context.startActivity(intent)
            }
        }
    }
}