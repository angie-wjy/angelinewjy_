package com.ubaya.uas_cerbung

import java.io.Serializable

data class Paragraf(val idPara: Int, val idWriter: Int,
                    val wriName: String, val para: String): Serializable {

                    }
