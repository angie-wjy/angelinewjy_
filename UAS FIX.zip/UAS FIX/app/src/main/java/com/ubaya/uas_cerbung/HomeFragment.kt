package com.ubaya.uas_cerbung

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.ubaya.uas_cerbung.databinding.FragmentHomeBinding
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import com.android.volley.toolbox.Volley
import org.json.JSONException

private const val ARG_CERBUNG = "cerbung"

class HomeFragment : Fragment(), HomeFragmentAdapter.OnReadClickListener{

    private var home: String? = null
    private lateinit var binding: FragmentHomeBinding
    var homes: ArrayList<Cerbung> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            home = it.getString(ARG_CERBUNG)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fetchDataFromServer()
    }

    private fun updateList() {
        val lm = LinearLayoutManager(activity)
        with(binding.RecyclerViewHome){
            layoutManager = lm
            setHasFixedSize(true)
            adapter = HomeFragmentAdapter(homes, requireContext(), this@HomeFragment)
        }
    }

    private fun fetchDataFromServer() {
        val url = "https://ubaya.me/native/160721016/cerbungs.php"

        val stringRequest = StringRequest(
            com.android.volley.Request.Method.POST, url,
            Response.Listener { response ->
                Log.d("apires", response.toString())
                try {
                    val jsonObj = JSONObject(response)
                    val dataArray = jsonObj.getJSONArray("data")

                    for (i in 0 until dataArray.length()) {
                        val cerbungObj = dataArray.getJSONObject(i)

                        // Ambil tanggal dari JSON
                        val tan = cerbungObj.getString("created")

                        val input1 = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        val date1 = input1.parse(tan)

                        val output1 = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val tgl1 = output1.format(date1)

                        val update = cerbungObj.getString("up")

                        val input2 = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        val date2 = input2.parse(update)
                        val output2 = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val tgl2 = output2.format(date2)

                        val cerbung = Cerbung(
                            cerbungObj.getString("id").toInt(),
                            cerbungObj.getString("title"),
                            cerbungObj.getString("desc"),
                            cerbungObj.getString("url"),
                            cerbungObj.getString("genre"),
                            cerbungObj.getString("access"),
                            tgl1, tgl2,
                            cerbungObj.getString("user"),
                        )
                        homes.add(cerbung)

                    }
                    updateList()
                    Log.d("checkarray", homes.toString())

                } catch (e: Exception){
                    Toast.makeText(requireContext(), "Error JSON", Toast.LENGTH_SHORT).show()
                    Log.e("apires", "Error JSON: ${e.message}")
                }
            },
            Response.ErrorListener { error ->
                Log.e("apires", error.message.toString())
            }
        )
    }

    companion object {
        fun newInstance(param1: String, param2: String) =
            HomeFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_CERBUNG, home)
                }
            }
        }

    override fun OnReadClickListener(cerbung: Cerbung) {
        val detail = ReadFragment.newInstance(cerbung)

        arguments = Bundle().apply {
            putParcelable(ARG_CERBUNG, cerbung)
        }
        activity?.supportFragmentManager?.beginTransaction()?.let {
            it.replace(R.id.containerHome, detail)
            it.addToBackStack(null)
            it.commit()
        }
    }
}
