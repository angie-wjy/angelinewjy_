package com.ubaya.uas_cerbung

import kotlinx.android.parcel.Parcelize
import java.io.Serializable
import android.os.Parcelable

@Parcelize
data class Cerbung(val id : Int, val title : String,
                   val desc : String, val url : String,
                   val genre : String, val access : String,
                   val paragraph : String, val date : String,
                   val user : String) : Parcelable {}
//Parcelize

