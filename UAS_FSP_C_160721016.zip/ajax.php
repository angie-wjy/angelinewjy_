<?php
    $const_color = array(
        array("color" => "Red",        "group"=>"light"),
        array("color" => "Dark Red",   "group"=>"dark"),
        array("color" => "White",      "group"=>"light"),
        array("color" => "Purple",     "group"=>"dark"),
        array("color" => "Brown",      "group"=>"dark"),
        array("color" => "Gray",       "group"=>"dark"),
        array("color" => "Black",      "group"=>"dark"),
        array("color" => "Cyan",       "group"=>"light"),
        array("color" => "Yellow",     "group"=>"light"),
        array("color" => "Light Blue", "group"=>"light"),
        array("color" => "Dark Blue",  "group"=>"dark"),
    );

    shuffle($const_color);

    if (isset($_POST['color_count'])) {
        $colorCount = $_POST['color_count'];
        shuffle($const_color);
        $selectedColors = array_slice($const_color, 0, $colorCount);
        echo json_encode($selectedColors);
    }

    // if (isset($_POST['color_count']) && is_numeric($_POST['color_count'])) {
    //     $selectedColors = array_slice($const_color, 0, $_POST['color_count']);
    //     shuffle($selectedColors);
    //     echo json_encode($selectedColors);
    // } else {
    //     echo json_encode([]);
    // }
?>